import React from "react";
import Home from "./pages/homepage/Home";



function App() {
  return (
    
    <>
   <Home/>
    
       
    </>
  );
}

export default App;
